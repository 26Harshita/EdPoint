# EdPoint: Student Mentor System | Place where we find teachers in your friends
// Explanation of what is it exactly
The link to the website is: http://tanishabisht.github.io/Project-EdPoint

## Why is this application important
// The importance of this appication in the long run ... explanation with proper statistical proof

## Features Offered by EdPoint
- User Authentication
- Create Courses
- Search for Courses
- Enroll for courses
- Discussion forum

## Future Developments
// Future prospects

## Dependencies
`styled-components` `bootstrap` `react-bootstrap` `node-sass` `gh-pages` `firebase` `react-firebase-hook` `tailwindcss` `css-modules`

## Team Mates
`Tanisha` `Aakriti` `Harshita`